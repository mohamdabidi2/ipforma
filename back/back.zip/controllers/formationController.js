const Formation = require('../models/formation');

// Create a new formation
exports.createFormation = async (req, res) => {
  try {
    const { title, description, durationWeeks, hoursPerWeek, type, reviews, content, professor ,price} = req.body;

    // Handle uploaded photos safely
    const photos = req.files ? req.files.map((file) => file.path) : [];

    // Parse incoming JSON fields if needed
    const parsedReviews = Array.isArray(reviews) ? reviews : reviews ? JSON.parse(reviews) : [];
    const parsedContent = Array.isArray(content) ? content : content ? JSON.parse(content) : [];

    const parsedProfessors = Array.isArray(professor)
    ? professor.map(p => (typeof p === "string" && p.startsWith("[object")) ? null : { name: p }).filter(Boolean)
    : professor ? [{ name: professor }] : [];
console.log(parsedProfessors,"body",professor)
    const formation = await Formation.create({
      title,
      description,
      durationWeeks,
      hoursPerWeek,
      type,
      price,
      photos,
      reviews: parsedReviews,
      content: parsedContent,
      professors: parsedProfessors,
    });

    res.status(201).json({ message: 'Formation created successfully', formation });
  } catch (error) {
    res.status(500).json({ message: `Failed to create formation: ${error.message}` });
  }
};

// Get all formations
exports.getFormations = async (req, res) => {
  try {
    const formations = await Formation.find();
    res.json(formations); // Return array directly
  } catch (error) {
    res.status(500).json({ message: `Failed to retrieve formations: ${error.message}` });
  }
};

exports.getFormationsList = async (req, res) => {
  try {
    const formations = await Formation.find({}, "title _id"); // Sélectionner uniquement l'ID et le titre
    res.status(200).json(formations);
  } catch (error) {
    console.error("Erreur lors de la récupération des formations:", error);
    res.status(500).json({ message: "Erreur serveur" });
  }
};

// Get a single formation by ID
exports.getFormationById = async (req, res) => {
  try {
    const { id } = req.params;
    const formation = await Formation.findById(id);
    if (!formation) {
      return res.status(404).json({ message: 'Formation not found' });
    }
    res.json(formation); // Return formation directly
  } catch (error) {
    res.status(500).json({ message: `Failed to retrieve formation: ${error.message}` });
  }
};

// Update a formation
exports.updateFormation = async (req, res) => {
  try {
    const { id } = req.params;
    const updates = { ...req.body };

    // Append new photos if provided
    if (req.files) {
      const newPhotos = req.files.map((file) => file.path);
      updates.photos = updates.photos ? updates.photos.concat(newPhotos) : newPhotos;
    }

    // Safely parse JSON fields if needed
    if (updates.reviews && typeof updates.reviews === 'string') {
      updates.reviews = JSON.parse(updates.reviews);
    }
    if (updates.content && typeof updates.content === 'string') {
      updates.content = JSON.parse(updates.content);
    }
    if (updates.professors && typeof updates.professors === 'string') {
      updates.professors = JSON.parse(updates.professors);
    }

    const formation = await Formation.findByIdAndUpdate(id, updates, { new: true });
    if (!formation) {
      return res.status(404).json({ message: 'Formation not found' });
    }

    res.json({ message: 'Formation updated successfully', formation });
  } catch (error) {
    res.status(500).json({ message: `Failed to update formation: ${error.message}` });
  }
};

// Delete a formation
exports.deleteFormation = async (req, res) => {
  try {
    const { id } = req.params;
    const formation = await Formation.findByIdAndDelete(id);
    if (!formation) {
      return res.status(404).json({ message: 'Formation not found' });
    }

    res.json({ message: 'Formation deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: `Failed to delete formation: ${error.message}` });
  }
};

