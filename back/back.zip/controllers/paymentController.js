const Payment = require("../models/Payment");
const PaymentAlert = require("../models/PaymentAlert");
const User = require("../models/User");
const Formation = require("../models/formation");

// Create a new payment with multiple tranches
exports.createPayment = async (req, res) => {
  try {
    const { userId, formationId, total, paymentType, tranches } = req.body;

    const newPayment = new Payment({
      userId,
      formationId,
      total,
      paymentType,
      tranches: tranches || [{ amount: total, dueDate: new Date(), status: 'pending' }],
      status: "pending",
    });

    await newPayment.save();
    res.status(201).json({ success: true, payment: newPayment });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Get all payments
exports.getAllPayments = async (req, res) => {
  try {
    const payments = await Payment.find()
      .populate("userId", "name lastname phone")
      .populate("formationId", "title price");
    res.status(200).json({ success: true, payments });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Get payments by user
exports.getPaymentsByUser = async (req, res) => {
  try {
    const payments = await Payment.find({ userId: req.params.userId })
      .populate("formationId", "title price");
    res.status(200).json({ success: true, payments });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Get user's own payments
exports.getMyPayments = async (req, res) => {
  try {
    const payments = await Payment.find({ userId: req.user._id })
      .populate("formationId", "title price");
    res.status(200).json({ success: true, payments });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Get payment by ID
exports.getPaymentById = async (req, res) => {
  try {
    const payment = await Payment.findById(req.params.id)
      .populate("userId", "name lastname phone")
      .populate("formationId", "title price");
    if (!payment) return res.status(404).json({ success: false, message: "Payment not found" });

    res.status(200).json({ success: true, payment });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Update a specific tranche (installment) of a payment
exports.updateTranchePayment = async (req, res) => {
  try {
    const { trancheIndex, amount } = req.body;
    const payment = await Payment.findById(req.params.id);

    if (!payment) return res.status(404).json({ success: false, message: "Payment not found" });

    if (trancheIndex >= payment.tranches.length) {
      return res.status(400).json({ success: false, message: "Invalid tranche index" });
    }

    // Update the specific tranche
    payment.tranches[trancheIndex].paidAt = new Date();
    payment.tranches[trancheIndex].status = 'paid';
    payment.updatedAt = new Date();

    // Check if all tranches are paid to mark the payment as completed
    if (payment.tranches.every(t => t.status === 'paid')) {
      payment.status = "completed";
    }

    await payment.save();

    // Create payment received alert
    const alert = new PaymentAlert({
      userId: payment.userId,
      formationId: payment.formationId,
      paymentId: payment._id,
      message: `Payment received for tranche ${trancheIndex + 1}`,
      type: 'payment_received',
      sentBy: req.user._id
    });
    await alert.save();

    res.status(200).json({ success: true, payment });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Send payment alert
exports.sendPaymentAlert = async (req, res) => {
  try {
    const { userId, formationId, message, type } = req.body;

    // Find pending payment for this user and formation
    const payment = await Payment.findOne({ 
      userId, 
      formationId, 
      status: 'pending' 
    });

    if (!payment) {
      return res.status(404).json({ success: false, message: "No pending payment found" });
    }

    const alert = new PaymentAlert({
      userId,
      formationId,
      paymentId: payment._id,
      message,
      type,
      sentBy: req.user._id
    });

    await alert.save();
    res.status(201).json({ success: true, alert });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Get payment alerts for user
exports.getPaymentAlerts = async (req, res) => {
  try {
    const alerts = await PaymentAlert.find({ userId: req.user._id })
      .populate("formationId", "title")
      .populate("sentBy", "name lastname")
      .sort({ createdAt: -1 });
    res.status(200).json({ success: true, alerts });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Mark alert as read
exports.markAlertAsRead = async (req, res) => {
  try {
    const alert = await PaymentAlert.findById(req.params.alertId);
    if (!alert) {
      return res.status(404).json({ success: false, message: "Alert not found" });
    }

    alert.isRead = true;
    await alert.save();

    res.status(200).json({ success: true, message: "Alert marked as read" });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Delete payment
exports.deletePayment = async (req, res) => {
  try {
    const payment = await Payment.findByIdAndDelete(req.params.id);
    if (!payment) return res.status(404).json({ success: false, message: "Payment not found" });

    res.status(200).json({ success: true, message: "Payment deleted successfully" });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Get overdue payments
exports.getOverduePayments = async (req, res) => {
  try {
    const today = new Date();
    const payments = await Payment.find({
      status: 'pending',
      'tranches.dueDate': { $lt: today },
      'tranches.status': 'pending'
    })
    .populate("userId", "name lastname phone")
    .populate("formationId", "title price");

    res.status(200).json({ success: true, payments });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

