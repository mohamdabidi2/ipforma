const Schedule = require("../models/Schedule");

// Create or update schedule
exports.saveSchedule = async (req, res) => {
  try {
    const { instructorId, week, schedule } = req.body;

    let existingSchedule = await Schedule.findOne({ instructorId, week });

    if (existingSchedule) {
      existingSchedule.schedule = schedule;
      await existingSchedule.save();
      return res.status(200).json({ message: "Schedule updated", schedule: existingSchedule });
    } else {
      const newSchedule = new Schedule({ instructorId, week, schedule });
      await newSchedule.save();
      return res.status(201).json({ message: "Schedule created", schedule: newSchedule });
    }
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
};

// Get schedule by instructor and week
exports.getSchedule = async (req, res) => {
  try {
    const { instructorId, week } = req.params;
    const schedule = await Schedule.findOne({ instructorId, week });

    if (!schedule) {
      return res.status(404).json({ message: "No schedule found" });
    }

    res.status(200).json(schedule);
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
};

// Delete schedule
exports.deleteSchedule = async (req, res) => {
  try {
    const { id } = req.params;
    await Schedule.findByIdAndDelete(id);
    res.status(200).json({ message: "Schedule deleted" });
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
};
