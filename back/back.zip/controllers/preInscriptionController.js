const PreInscription = require("../models/PreInscription");
const Payment = require("../models/Payment");
const Formation = require("../models/formation");
// ✅ Get all pre-inscriptions
exports.getPreInscriptions = async (req, res) => {
  try {
    const inscriptions = await PreInscription.find().populate("professeurResponsable", "name");
    res.status(200).json(inscriptions);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// ✅ Get a single pre-inscription by ID
exports.getPreInscriptionById = async (req, res) => {
  try {
    const inscription = await PreInscription.findById(req.params.id).populate("professeurResponsable", "name");
    if (!inscription) return res.status(404).json({ message: "Pre-Inscription not found" });

    res.status(200).json(inscription);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// ✅ Create a new pre-inscription
exports.createPreInscription = async (req, res) => {
  try {
    let formationId=req.body.formation.id
    // Fetch formation price
    const formation = await Formation.findById(formationId);
    if (!formation) {
      return res.status(404).json({ error: "Formation not found" });
    }

    const montantTotal = formation.price; // Get the formation price

    // Create a new pre-inscription
    const newInscription = new PreInscription(req.body);
    await newInscription.save();

    // Create a new payment with the first tranche
    const newPayment = new Payment({
      userId:req.body.userId,
      total: montantTotal,
      tranches: [
        {
          amount: req.body.montantTotal, // First tranche is the full amount
          paidAt: new Date(), // Mark as paid immediately
        }
      ],
      status:req.body.montantTotal!= montantTotal?"pending":"completed", // Since the full amount is paid
    });

    await newPayment.save();

    res.status(201).json({ inscription: newInscription, payment: newPayment });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// ✅ Update a pre-inscription
exports.updatePreInscription = async (req, res) => {
  try {
    const updatedInscription = await PreInscription.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!updatedInscription) return res.status(404).json({ message: "Pre-Inscription not found" });

    res.status(200).json(updatedInscription);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// ✅ Delete a pre-inscription
exports.deletePreInscription = async (req, res) => {
  try {
    const deletedInscription = await PreInscription.findByIdAndDelete(req.params.id);
    if (!deletedInscription) return res.status(404).json({ message: "Pre-Inscription not found" });

    res.status(200).json({ message: "Pre-Inscription deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
