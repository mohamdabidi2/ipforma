const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const connectDB = require('./config/db');
const path = require('path');

dotenv.config();
connectDB();
const app = express();

// CORS configuration
app.use(cors({
  origin: '*',
  credentials: true
}));

app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Routes
app.use('/api/users', require('./routes/userRoutes'));
app.use('/api/formations', require('./routes/formationRoutes'));
app.use('/api/schedules', require('./routes/scheduleRoutes'));
app.use('/api/preinscriptions', require('./routes/preInscriptionRoutes'));
app.use('/api/payments', require('./routes/paymentRoutes'));
app.use('/api/teacher-spaces', require('./routes/teacherSpaceRoutes'));
app.use('/api/qcms', require('./routes/qcmRoutes'));
app.use('/api/statistics', require('./routes/statisticsRoutes'));

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ message: 'IPforma API is running', timestamp: new Date().toISOString() });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on port ${PORT}`);
});

