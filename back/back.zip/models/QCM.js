const mongoose = require('mongoose');

const qcmSchema = new mongoose.Schema({
  teacherId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User', 
    required: true 
  },
  formationId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Formation', 
    required: true 
  },
  title: { type: String, required: true },
  description: { type: String },
  questions: [{
    question: { type: String, required: true },
    options: [{ type: String, required: true }],
    correctAnswer: { type: Number, required: true }, // Index of correct option
    points: { type: Number, default: 1 }
  }],
  duration: { type: Number, required: true }, // Duration in minutes
  students: [{ 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User' 
  }],
  results: [{
    studentId: { 
      type: mongoose.Schema.Types.ObjectId, 
      ref: 'User', 
      required: true 
    },
    answers: [{ type: Number }], // Array of selected option indices
    score: { type: Number, required: true },
    totalPoints: { type: Number, required: true },
    completedAt: { type: Date, default: Date.now }
  }],
  isActive: { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('QCM', qcmSchema);

