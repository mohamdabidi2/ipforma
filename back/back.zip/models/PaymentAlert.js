const mongoose = require("mongoose");

const PaymentAlertSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  formationId: { type: mongoose.Schema.Types.ObjectId, ref: "Formation", required: true },
  paymentId: { type: mongoose.Schema.Types.ObjectId, ref: "Payment", required: true },
  message: { type: String, required: true },
  type: { type: String, enum: ["reminder", "overdue", "payment_received"], required: true },
  isRead: { type: Boolean, default: false },
  sentBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("PaymentAlert", PaymentAlertSchema);

