const mongoose = require('mongoose');

const teacherSpaceSchema = new mongoose.Schema({
  teacherId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User', 
    required: true 
  },
  formationId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Formation', 
    required: true 
  },
  title: { type: String, required: true },
  description: { type: String },
  password: { type: String, required: true },
  files: [{
    name: { type: String, required: true },
    path: { type: String, required: true },
    type: { type: String, required: true }, // file, link, image, video
    uploadedAt: { type: Date, default: Date.now }
  }],
  links: [{
    title: { type: String, required: true },
    url: { type: String, required: true },
    addedAt: { type: Date, default: Date.now }
  }],
  students: [{ 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User' 
  }],
  isActive: { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('TeacherSpace', teacherSpaceSchema);

