const mongoose = require('mongoose');

const formationSchema = new mongoose.Schema({
  price:{ type: Number, required: true },
  title: { type: String, required: true },
  description: { type: String, required: true },
  durationWeeks: { type: Number, required: true },
  hoursPerWeek: { type: Number, required: true },
  type: { type: String, enum: ['en ligne', 'presentielle'], required: true },
  photos: [{ type: String }], // Array of photo file paths
  reviews: [
    {
      reviewerName: { type: String, required: true },
      rating: { type: Number, min: 1, max: 5, required: true },
      comment: { type: String, required: true },
      date: { type: Date, default: Date.now },
    },
  ],
  content: [
    {
      chapterTitle: { type: String, required: true },
      description: { type: String },
      durationMinutes: { type: Number },
    },
  ],
  professors: [
    {
      name: { type: String, required: true },
      bio: { type: String },
      photo: { type: String },
    },
  ],
});

module.exports = mongoose.model('Formation', formationSchema);
