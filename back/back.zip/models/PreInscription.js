const mongoose = require("mongoose");

const PreInscriptionSchema = new mongoose.Schema({
  nom: { type: String, required: true },
  userId:{ type: String, required: true },
  formation: {
    titre: { type: String, required: true },
    id: { type: String, required: true }
  },
  statut: { type: String, enum: ["en attente", "révisé", "accepté"], default: "en attente" },
  modeDePaiement: { type: String, required: false },
  montantTotal: { type: Number, required: false },
  professeurResponsable: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
}, { timestamps: true });

module.exports = mongoose.model("PreInscription", PreInscriptionSchema);
