const express = require("express");
const router = express.Router();
const scheduleController = require("../controllers/scheduleController");

router.post("/save", scheduleController.saveSchedule);
router.get("/:instructorId/:week", scheduleController.getSchedule);
router.delete("/:id", scheduleController.deleteSchedule);

module.exports = router;
