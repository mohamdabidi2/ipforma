const express = require('express');
const router = express.Router();
const Statistics = require('../models/Statistics');
const User = require('../models/User');
const Formation = require('../models/formation');
const Payment = require('../models/Payment');
const PreInscription = require('../models/PreInscription');
const { protect, authorize } = require('../middlewares/authMiddleware');

// Get dashboard statistics
router.get('/dashboard', protect, authorize(['admin', 'reception']), async (req, res) => {
  try {
    const today = new Date();
    const startOfDay = new Date(today.setHours(0, 0, 0, 0));
    const endOfDay = new Date(today.setHours(23, 59, 59, 999));

    // Get today's inscriptions
    const todayInscriptions = await PreInscription.countDocuments({
      createdAt: { $gte: startOfDay, $lte: endOfDay }
    });

    // Get total payments today
    const todayPayments = await Payment.aggregate([
      {
        $match: {
          createdAt: { $gte: startOfDay, $lte: endOfDay },
          status: 'completed'
        }
      },
      {
        $group: {
          _id: null,
          total: { $sum: '$total' }
        }
      }
    ]);

    // Get unpaid payments
    const unpaidPayments = await Payment.aggregate([
      {
        $match: { status: 'pending' }
      },
      {
        $group: {
          _id: null,
          total: { $sum: '$total' }
        }
      }
    ]);

    // Get user counts
    const totalStudents = await User.countDocuments({ role: 'student', isActive: true });
    const totalTeachers = await User.countDocuments({ role: 'teacher', isActive: true });
    const totalFormations = await Formation.countDocuments();

    // Get weekly inscription chart data
    const weeklyData = await PreInscription.aggregate([
      {
        $match: {
          createdAt: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) }
        }
      },
      {
        $group: {
          _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } },
          count: { $sum: 1 }
        }
      },
      { $sort: { _id: 1 } }
    ]);

    res.json({
      todayInscriptions,
      todayPayments: todayPayments[0]?.total || 0,
      unpaidPayments: unpaidPayments[0]?.total || 0,
      totalStudents,
      totalTeachers,
      totalFormations,
      weeklyInscriptions: weeklyData
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get platform statistics for home page
router.get('/platform', async (req, res) => {
  try {
    const totalTeachers = await User.countDocuments({ role: 'teacher', isActive: true });
    const totalFormations = await Formation.countDocuments();
    const totalStudents = await User.countDocuments({ role: 'student', isActive: true });
    const yearsOfExperience = 10; // Static value as requested

    res.json({
      teachers: totalTeachers,
      courses: totalFormations,
      experience: yearsOfExperience,
      users: totalStudents
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update daily statistics (can be called by cron job)
router.post('/update-daily', protect, authorize(['admin']), async (req, res) => {
  try {
    const today = new Date();
    const startOfDay = new Date(today.setHours(0, 0, 0, 0));
    const endOfDay = new Date(today.setHours(23, 59, 59, 999));

    const todayInscriptions = await PreInscription.countDocuments({
      createdAt: { $gte: startOfDay, $lte: endOfDay }
    });

    const todayPayments = await Payment.aggregate([
      {
        $match: {
          createdAt: { $gte: startOfDay, $lte: endOfDay },
          status: 'completed'
        }
      },
      {
        $group: {
          _id: null,
          total: { $sum: '$total' }
        }
      }
    ]);

    const unpaidPayments = await Payment.aggregate([
      {
        $match: { status: 'pending' }
      },
      {
        $group: {
          _id: null,
          total: { $sum: '$total' }
        }
      }
    ]);

    const activeStudents = await User.countDocuments({ role: 'student', isActive: true });
    const activeTeachers = await User.countDocuments({ role: 'teacher', isActive: true });
    const totalFormations = await Formation.countDocuments();

    await Statistics.findOneAndUpdate(
      { date: startOfDay },
      {
        newInscriptions: todayInscriptions,
        totalPayments: todayPayments[0]?.total || 0,
        unpaidPayments: unpaidPayments[0]?.total || 0,
        activeStudents,
        activeTeachers,
        totalFormations
      },
      { upsert: true, new: true }
    );

    res.json({ message: 'Statistics updated successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;

