const express = require('express');
const upload = require('../middlewares/uploadMiddleware');
const { protect, authorize } = require('../middlewares/authMiddleware');
const {
  createFormation,
  getFormations,
  getFormationsList,
  updateFormation,
  getFormationById,
  deleteFormation,
} = require('../controllers/formationController');

const router = express.Router();

// Public routes
router.get('/', getFormations);
router.get('/list/all', getFormationsList);
router.get('/:id', getFormationById);

// Protected routes (admin only)
router.post('/', protect, authorize(['admin']), upload.array('photos'), createFormation);
router.put('/:id', protect, authorize(['admin']), upload.array('photos'), updateFormation);
router.delete('/:id', protect, authorize(['admin']), deleteFormation);

module.exports = router;

