const express = require("express");
const router = express.Router();
const preInscriptionController = require("../controllers/preInscriptionController");

// GET all pre-inscriptions
router.get("/", preInscriptionController.getPreInscriptions);

// GET a single pre-inscription by ID
router.get("/:id", preInscriptionController.getPreInscriptionById);

// POST a new pre-inscription
router.post("/", preInscriptionController.createPreInscription);

// PUT (update) an existing pre-inscription
router.put("/:id", preInscriptionController.updatePreInscription);

// DELETE a pre-inscription
router.delete("/:id", preInscriptionController.deletePreInscription);

module.exports = router;
