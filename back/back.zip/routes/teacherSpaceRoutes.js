const express = require('express');
const router = express.Router();
const TeacherSpace = require('../models/TeacherSpace');
const { protect, authorize } = require('../middlewares/authMiddleware');
const upload = require('../middlewares/uploadMiddleware');

// Create teacher space
router.post('/', protect, authorize(['teacher']), async (req, res) => {
  try {
    const { formationId, title, description, password } = req.body;
    
    const teacherSpace = new TeacherSpace({
      teacherId: req.user._id,
      formationId,
      title,
      description,
      password
    });

    await teacherSpace.save();
    res.status(201).json(teacherSpace);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Get teacher spaces by teacher
router.get('/my-spaces', protect, authorize(['teacher']), async (req, res) => {
  try {
    const spaces = await TeacherSpace.find({ teacherId: req.user._id })
      .populate('formationId', 'title')
      .populate('students', 'name lastname');
    res.json(spaces);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get teacher space by ID
router.get('/:id', protect, async (req, res) => {
  try {
    const space = await TeacherSpace.findById(req.params.id)
      .populate('formationId', 'title')
      .populate('students', 'name lastname')
      .populate('teacherId', 'name lastname');
    
    if (!space) {
      return res.status(404).json({ message: 'Teacher space not found' });
    }

    res.json(space);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Access teacher space with password
router.post('/:id/access', protect, authorize(['student']), async (req, res) => {
  try {
    const { password } = req.body;
    const space = await TeacherSpace.findById(req.params.id);
    
    if (!space) {
      return res.status(404).json({ message: 'Teacher space not found' });
    }

    if (space.password !== password) {
      return res.status(401).json({ message: 'Invalid password' });
    }

    // Add student to space if not already added
    if (!space.students.includes(req.user._id)) {
      space.students.push(req.user._id);
      await space.save();
    }

    res.json({ message: 'Access granted', spaceId: space._id });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Upload file to teacher space
router.post('/:id/upload', protect, authorize(['teacher']), upload.single('file'), async (req, res) => {
  try {
    const space = await TeacherSpace.findById(req.params.id);
    
    if (!space || space.teacherId.toString() !== req.user._id.toString()) {
      return res.status(404).json({ message: 'Teacher space not found' });
    }

    const fileData = {
      name: req.file.originalname,
      path: req.file.path,
      type: 'file'
    };

    space.files.push(fileData);
    await space.save();

    res.json(fileData);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Add link to teacher space
router.post('/:id/links', protect, authorize(['teacher']), async (req, res) => {
  try {
    const { title, url } = req.body;
    const space = await TeacherSpace.findById(req.params.id);
    
    if (!space || space.teacherId.toString() !== req.user._id.toString()) {
      return res.status(404).json({ message: 'Teacher space not found' });
    }

    const linkData = { title, url };
    space.links.push(linkData);
    await space.save();

    res.json(linkData);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get student's accessible spaces
router.get('/student/my-spaces', protect, authorize(['student']), async (req, res) => {
  try {
    const spaces = await TeacherSpace.find({ students: req.user._id })
      .populate('formationId', 'title')
      .populate('teacherId', 'name lastname');
    res.json(spaces);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;

