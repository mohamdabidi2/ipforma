const express = require("express");
const router = express.Router();
const paymentController = require("../controllers/paymentController");
const { protect, authorize } = require("../middlewares/authMiddleware");

// Admin and reception routes
router.post("/create", protect, authorize(['admin', 'reception']), paymentController.createPayment);
router.get("/", protect, authorize(['admin', 'reception']), paymentController.getAllPayments);
router.get("/overdue", protect, authorize(['admin', 'reception']), paymentController.getOverduePayments);
router.get("/user/:userId", protect, authorize(['admin', 'reception']), paymentController.getPaymentsByUser);
router.put("/:id/tranche", protect, authorize(['admin', 'reception']), paymentController.updateTranchePayment);
router.post("/send-alert", protect, authorize(['admin', 'reception']), paymentController.sendPaymentAlert);
router.delete("/:id", protect, authorize(['admin']), paymentController.deletePayment);

// Student routes
router.get("/my-payments", protect, authorize(['student']), paymentController.getMyPayments);
router.get("/my-alerts", protect, authorize(['student']), paymentController.getPaymentAlerts);
router.put("/alerts/:alertId/read", protect, authorize(['student']), paymentController.markAlertAsRead);

// General routes
router.get("/:id", protect, paymentController.getPaymentById);

module.exports = router;

