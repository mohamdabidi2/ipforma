const express = require('express');
const router = express.Router();
const QCM = require('../models/QCM');
const { protect, authorize } = require('../middlewares/authMiddleware');

// Create QCM
router.post('/', protect, authorize(['teacher']), async (req, res) => {
  try {
    const { formationId, title, description, questions, duration, students } = req.body;
    
    const qcm = new QCM({
      teacherId: req.user._id,
      formationId,
      title,
      description,
      questions,
      duration,
      students
    });

    await qcm.save();
    res.status(201).json(qcm);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Get QCMs by teacher
router.get('/my-qcms', protect, authorize(['teacher']), async (req, res) => {
  try {
    const qcms = await QCM.find({ teacherId: req.user._id })
      .populate('formationId', 'title')
      .populate('students', 'name lastname');
    res.json(qcms);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get QCMs for student
router.get('/student/my-qcms', protect, authorize(['student']), async (req, res) => {
  try {
    const qcms = await QCM.find({ students: req.user._id })
      .populate('formationId', 'title')
      .populate('teacherId', 'name lastname')
      .select('-questions.correctAnswer'); // Hide correct answers
    res.json(qcms);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get QCM by ID (for taking test)
router.get('/:id', protect, authorize(['student']), async (req, res) => {
  try {
    const qcm = await QCM.findById(req.params.id)
      .populate('formationId', 'title')
      .populate('teacherId', 'name lastname')
      .select('-questions.correctAnswer'); // Hide correct answers
    
    if (!qcm) {
      return res.status(404).json({ message: 'QCM not found' });
    }

    // Check if student is allowed to take this QCM
    if (!qcm.students.includes(req.user._id)) {
      return res.status(403).json({ message: 'Access denied' });
    }

    res.json(qcm);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Submit QCM answers
router.post('/:id/submit', protect, authorize(['student']), async (req, res) => {
  try {
    const { answers } = req.body;
    const qcm = await QCM.findById(req.params.id);
    
    if (!qcm) {
      return res.status(404).json({ message: 'QCM not found' });
    }

    // Check if student already submitted
    const existingResult = qcm.results.find(r => r.studentId.toString() === req.user._id.toString());
    if (existingResult) {
      return res.status(400).json({ message: 'QCM already submitted' });
    }

    // Calculate score
    let score = 0;
    let totalPoints = 0;
    
    qcm.questions.forEach((question, index) => {
      totalPoints += question.points;
      if (answers[index] === question.correctAnswer) {
        score += question.points;
      }
    });

    const result = {
      studentId: req.user._id,
      answers,
      score,
      totalPoints
    };

    qcm.results.push(result);
    await qcm.save();

    res.json({ score, totalPoints, percentage: (score / totalPoints) * 100 });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get QCM results (teacher only)
router.get('/:id/results', protect, authorize(['teacher']), async (req, res) => {
  try {
    const qcm = await QCM.findById(req.params.id)
      .populate('results.studentId', 'name lastname');
    
    if (!qcm || qcm.teacherId.toString() !== req.user._id.toString()) {
      return res.status(404).json({ message: 'QCM not found' });
    }

    res.json(qcm.results);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get student's QCM result
router.get('/:id/my-result', protect, authorize(['student']), async (req, res) => {
  try {
    const qcm = await QCM.findById(req.params.id);
    
    if (!qcm) {
      return res.status(404).json({ message: 'QCM not found' });
    }

    const result = qcm.results.find(r => r.studentId.toString() === req.user._id.toString());
    
    if (!result) {
      return res.status(404).json({ message: 'Result not found' });
    }

    res.json(result);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;

